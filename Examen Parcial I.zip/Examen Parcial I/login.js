document.getElementById("loginForm").addEventListener("submit", async function(e) {
  e.preventDefault();
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const mensaje = document.getElementById("mensaje");

  try {
    const res = await fetch("https://fakestoreapi.com/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();

    if (data.token) {
      mensaje.textContent = "¡Login exitoso!";
      mensaje.className = "text-green-500 text-center mt-4";
      localStorage.setItem("token", data.token); 
      setTimeout(() => {
        window.location.href = "index.html";
      }, 1200);
    } else {
      mensaje.textContent = "Usuario o contraseña incorrectos";
      mensaje.className = "text-red-500 text-center mt-4";
    }
  } catch (error) {
    mensaje.textContent = "Error al conectar con el servidor";
    mensaje.className = "text-red-500 text-center mt-4";
  }
});